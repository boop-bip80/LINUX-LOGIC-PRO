extern "C" int printf(const char *, ...);
extern "C" const char *register_name(int);
int main() {
  for (volatile int value = -8; value <= 40; ++value)
    printf("%d %s\n", value, register_name(value));
  volatile int lower = (-2147483647 - 1), upper = 2147483647;
  printf("%d %s\n", lower, register_name(lower));
  printf("%d %s\n", upper, register_name(upper));
  return 0;
}
