// Function and enum values extracted unchanged from pinned LLVM libunwind.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// https://llvm.org/LICENSE.txt
namespace libunwind {
enum {
UNW_REG_IP = -1,
UNW_REG_SP = -2,
UNW_X86_64_R10 = 10,
UNW_X86_64_R11 = 11,
UNW_X86_64_R12 = 12,
UNW_X86_64_R13 = 13,
UNW_X86_64_R14 = 14,
UNW_X86_64_R15 = 15,
UNW_X86_64_R8 = 8,
UNW_X86_64_R9 = 9,
UNW_X86_64_RAX = 0,
UNW_X86_64_RBP = 6,
UNW_X86_64_RBX = 3,
UNW_X86_64_RCX = 2,
UNW_X86_64_RDI = 5,
UNW_X86_64_RDX = 1,
UNW_X86_64_RSI = 4,
UNW_X86_64_RSP = 7,
UNW_X86_64_XMM0 = 17,
UNW_X86_64_XMM1 = 18,
UNW_X86_64_XMM10 = 27,
UNW_X86_64_XMM11 = 28,
UNW_X86_64_XMM12 = 29,
UNW_X86_64_XMM13 = 30,
UNW_X86_64_XMM14 = 31,
UNW_X86_64_XMM15 = 32,
UNW_X86_64_XMM2 = 19,
UNW_X86_64_XMM3 = 20,
UNW_X86_64_XMM4 = 21,
UNW_X86_64_XMM5 = 22,
UNW_X86_64_XMM6 = 23,
UNW_X86_64_XMM7 = 24,
UNW_X86_64_XMM8 = 25,
UNW_X86_64_XMM9 = 26
};
class Registers_x86_64 { public: static const char *getRegisterName(int); };
inline const char *Registers_x86_64::getRegisterName(int regNum) {
  switch (regNum) {
  case UNW_REG_IP:
    return "rip";
  case UNW_REG_SP:
    return "rsp";
  case UNW_X86_64_RAX:
    return "rax";
  case UNW_X86_64_RDX:
    return "rdx";
  case UNW_X86_64_RCX:
    return "rcx";
  case UNW_X86_64_RBX:
    return "rbx";
  case UNW_X86_64_RSI:
    return "rsi";
  case UNW_X86_64_RDI:
    return "rdi";
  case UNW_X86_64_RBP:
    return "rbp";
  case UNW_X86_64_RSP:
    return "rsp";
  case UNW_X86_64_R8:
    return "r8";
  case UNW_X86_64_R9:
    return "r9";
  case UNW_X86_64_R10:
    return "r10";
  case UNW_X86_64_R11:
    return "r11";
  case UNW_X86_64_R12:
    return "r12";
  case UNW_X86_64_R13:
    return "r13";
  case UNW_X86_64_R14:
    return "r14";
  case UNW_X86_64_R15:
    return "r15";
  case UNW_X86_64_XMM0:
    return "xmm0";
  case UNW_X86_64_XMM1:
    return "xmm1";
  case UNW_X86_64_XMM2:
    return "xmm2";
  case UNW_X86_64_XMM3:
    return "xmm3";
  case UNW_X86_64_XMM4:
    return "xmm4";
  case UNW_X86_64_XMM5:
    return "xmm5";
  case UNW_X86_64_XMM6:
    return "xmm6";
  case UNW_X86_64_XMM7:
    return "xmm7";
  case UNW_X86_64_XMM8:
    return "xmm8";
  case UNW_X86_64_XMM9:
    return "xmm9";
  case UNW_X86_64_XMM10:
    return "xmm10";
  case UNW_X86_64_XMM11:
    return "xmm11";
  case UNW_X86_64_XMM12:
    return "xmm12";
  case UNW_X86_64_XMM13:
    return "xmm13";
  case UNW_X86_64_XMM14:
    return "xmm14";
  case UNW_X86_64_XMM15:
    return "xmm15";
  default:
    return "unknown register";
  }
}
}
extern "C" __attribute__((noinline)) const char *register_name(int number) {
  return libunwind::Registers_x86_64::getRegisterName(number);
}
